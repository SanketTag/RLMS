angular
  .module('theme.core.panels', ['ngDraggable'])
  .config(function() {});