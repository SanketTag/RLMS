angular
  .module('theme.core.directives', []);